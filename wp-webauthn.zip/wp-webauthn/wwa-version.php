<?php
$wwa_version = array(
    'version' => '1.3.1',
    'commit' => '79260d5'
);
?>